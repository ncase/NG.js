NG.JS - An HTML5 port of the Newgrounds Flash API.
===

DEMO on NEWGROUNDS: http://www.newgrounds.com/projects/games/646548/preview

Special thanks to the Newgrounds team, of course!
This Newgrounds API is unofficial, it's just made by a long-time fan of the site.
All code here is open source, under the public domain Unlicense.